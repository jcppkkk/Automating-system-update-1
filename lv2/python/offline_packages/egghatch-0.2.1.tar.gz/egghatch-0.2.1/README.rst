Egghatch (tm)
=============

Shellcode identification & formatting.
